UPDATE chatRoom
SET cookie = exchange || '-' || '0' || '-' || name;
